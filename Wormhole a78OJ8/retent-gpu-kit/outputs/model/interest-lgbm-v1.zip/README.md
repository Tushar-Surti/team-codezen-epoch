# Retent interest model: interest-lgbm-v1

LightGBM interest scorer for retent_core's engine, trained on 338 transcribed videos
(Whisper large-v3 + YouTube captions), with each video's YouTube "Most replayed" curve as the target.

## Use

1. Copy `interest.py` to `ml/src/retent_ml/interest.py` and the `interest-lgbm-v1/` folder anywhere.
2. `uv sync` (needs `lightgbm`, already in retent-ml's dependencies).
3. Pass the model to the pipeline:

```python
from retent_ml.interest import LGBMInterest
model = LGBMInterest.load("path/to/interest-lgbm-v1")
analysis = analyze_sentences(sents, meta, model=model)   # or simulator.run(..., model=model)
```

Contributions are exact SHAP values per feature, so flags and fixes work unchanged.

## How good

Per-video Spearman correlation with the real curve after the first 10% of the video, on held-out
channels (5-fold, grouped by channel): **0.212** for this model, 0.125 for timing alone, 0.033 for the
heuristic-v0 scorer. It picks up where interest rises and falls; it is not an exact curve. Full
numbers, per-cell scores and feature gains are in `card.json`.
